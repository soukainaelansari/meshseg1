
import "./App.css";
import  ObjectUploader from "./components/upload/upload.js";
 



const App = () => {
 return (
    <div className="container">
    
            < ObjectUploader/>
        
    </div>
    
   )
};

export default App;
