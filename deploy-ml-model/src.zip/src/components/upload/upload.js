
import React, { useState, useRef, useEffect } from 'react';
import * as THREE from 'three';

function ObjectUploader() {
  const [objectPreview, setObjectPreview] = useState(null);
  const canvasRef = useRef();

  useEffect(() => {
    if (objectPreview) {
      const canvas = canvasRef.current;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;

      const renderer = new THREE.WebGLRenderer({ canvas: canvas });
      renderer.setSize(width, height);

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
      camera.position.set(0, 0, 5);

      const loader = new THREE.ObjectLoader();
      loader.load(
        objectPreview,
        (object) => {
          scene.add(object);
          scene.add(new THREE.AmbientLight(0xffffff));
        },
        undefined,
        (error) => {
          console.error(error);
        }
      );

      const animate = () => {
        requestAnimationFrame(animate);
        renderer.render(scene, camera);
      };
      animate();
    }
  }, [objectPreview]);

  const handleObjectUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setObjectPreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <h1>Object Uploader</h1>
      <input type="file" accept=".json,.obj,.gltf,.glb, .stl" onChange={handleObjectUpload} />
      {objectPreview && <canvas ref={canvasRef} />}
    </div>
  );
}

export default ObjectUploader;